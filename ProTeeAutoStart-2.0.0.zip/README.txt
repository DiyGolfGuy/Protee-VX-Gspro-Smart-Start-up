ProTee AutoStart v2.0.0
BA Custom Products - www.bacustomproducts.com

Hands-off startup for golf simulator bays. Runs at PC boot, clicks through
GSPro/ProTee to the practice range (or the GSPro main menu if you prefer),
and can power-cycle your launch monitor over a Shelly plug if it fails to
connect.

INSTALL
1. Put ProTeeAutoStart.exe somewhere permanent, e.g. C:\ProTeeAutoStart\
2. Run it once - the Setup window opens. Fill in your settings, click Save.
3. Press Win+R, type: shell:startup  and drop a shortcut to the exe there.

KEYS
- S during the startup countdown = open Setup
- ESC any time = abort the sequence

WINDOWS SMARTSCREEN
The exe is not code-signed yet, so the first run may show a blue
"Windows protected your PC" box. Click More info, then Run anyway.
If the file is blocked: right-click it, Properties, tick Unblock, OK.

VERIFY YOUR DOWNLOAD
SHA-256 of ProTeeAutoStart.exe:
de1921bdd9b85608091788dec0bf5caf9d8586343d7cba5723699e30fc791400

Full documentation, source code, and updates:
https://github.com/DiyGolfGuy/Protee-VX-Gspro-Smart-Start-up
